using System;
using System.Globalization;
using System.IO;
using System.Text;

namespace PostDP40VoidChecks;

internal sealed record BatchSummary(int Posted, int AlreadyDone, int Skipped, bool StoppedEarly, string FilePath);

/// <summary>The batch stopped part-way; the message says where it stopped and what state the row was left in.</summary>
internal sealed class BatchInterruptedException : Exception
{
    public BatchInterruptedException(string message, Exception inner) : base(message, inner) { }
}

/// <summary>
/// VB6 Process_Sheet_Click: walk sheet 1 of the spreadsheet and post every row whose column T is still empty.
/// </summary>
internal sealed class BatchRunner
{
    private const int ResultColumn = 20; // column T

    private readonly TopsAutomation _tops;
    private readonly IOperator _op;
    private readonly string _backupFolder;

    public BatchRunner(TopsAutomation tops, IOperator op, string backupFolder)
    {
        _tops = tops;
        _op = op;
        _backupFolder = backupFolder;
    }

    public BatchSummary Run(string sourceFile, int saveEvery, Func<bool> stopRequested, Func<bool> takeSaveRequest)
    {
        string path = Path.GetFullPath(sourceFile);
        if (!File.Exists(path))
            throw new FileNotFoundException("Can't find the source file-- " + path, path);

        WaitUntilFileIsFree(path);
        _op.Log("Backup of the spreadsheet before this run: " + BackUp(path));

        using ExcelWorkbook book = ExcelWorkbook.Open(path);
        int lastRow = book.LastUsedRow(2); // VB6: Cells(65530, 2).End(xlUp).Row
        _op.Log($"Opened {Path.GetFileName(path)}, sheet \"{book.SheetName}\", rows 1 to {lastRow}.");

        int posted = 0, alreadyDone = 0, skipped = 0, sinceSave = 0;
        int rowInFlight = 0;
        bool resultRecorded = false;
        bool stoppedEarly = false;
        Exception? failure = null;

        try
        {
            for (int row = 1; row <= lastRow; row++)
            {
                if (stopRequested())
                {
                    stoppedEarly = true;
                    _op.Log($"Stopped on request before row {row}.");
                    break;
                }

                // "Save every N" (the VB6 counter was never incremented, so it never saved) and the Save now button.
                if (takeSaveRequest() || (saveEvery > 0 && sinceSave >= saveEvery))
                {
                    _op.Status("Saving the spreadsheet--");
                    book.Save();
                    sinceSave = 0;
                    _op.Log("Spreadsheet saved.");
                }

                VoidCheckRow input = VoidCheckRow.Read(book, row);
                _op.Status($"Working on sheet {book.SheetName} -- row {row} / {lastRow} -- disb acct {input.DisbAcct}, check # {input.CheckNumber}");

                // Rows that already have a result in column T were done on an earlier run.
                if (VbCompat.TU(book.Read(row, ResultColumn).Text).Length > 0)
                {
                    alreadyDone++;
                    continue;
                }

                string? problem = input.Validate();
                if (problem is not null)
                {
                    if (!input.IsBlank)
                    {
                        skipped++;
                        _op.Log($"Row {row} skipped: {problem}.");
                    }
                    continue;
                }

                int currentRow = row;
                rowInFlight = currentRow;
                resultRecorded = false;
                _op.Log($"Row {currentRow}: posting {input.Describe()}.");

                _tops.PostVoidOrStop(input, message =>
                {
                    string stamped = VbCompat.ResultStamp(message, DateTime.Now);
                    book.Write(currentRow, ResultColumn, stamped);
                    resultRecorded = true;
                    _op.Log($"Row {currentRow} result: {stamped}");
                });

                rowInFlight = 0;
                posted++;
                sinceSave++;
            }
        }
        catch (Exception ex)
        {
            failure = ex;
        }

        bool saved = TrySave(book);

        if (failure is not null)
            throw new BatchInterruptedException(Explain(failure, rowInFlight, _tops.PostSubmitted, resultRecorded, saved), failure);

        if (!saved)
            throw new IOException("Every row was processed, but the spreadsheet could NOT be saved. The run log has every result.");

        return new BatchSummary(posted, alreadyDone, skipped, stoppedEarly, path);
    }

    private bool TrySave(ExcelWorkbook book)
    {
        try
        {
            book.Save();
            _op.Log("Spreadsheet saved.");
            return true;
        }
        catch (Exception ex)
        {
            _op.Log("COULD NOT SAVE THE SPREADSHEET: " + ex.Message);
            return false;
        }
    }

    private static string Explain(Exception failure, int rowInFlight, bool submitted, bool recorded, bool saved)
    {
        string nl = Environment.NewLine;
        var sb = new StringBuilder();
        sb.Append(failure is OperationCanceledException ? "The run was stopped." : "The run stopped: " + failure.Message);

        if (rowInFlight > 0)
        {
            sb.Append(nl).Append(nl);
            if (recorded)
                sb.Append($"Row {rowInFlight}: its TOPS result is already in column T. The stop happened on the way back to the main menu.");
            else if (submitted)
                sb.Append($"Row {rowInFlight}: the DP40 request WAS submitted, but no result was recorded and column T is blank. " +
                          "Look the check up in TOPS before running again. If it posted, put a note in column T so the rerun skips it.");
            else
                sb.Append($"Row {rowInFlight}: stopped before the DP40 request was submitted, so nothing was posted for it. " +
                          "Column T is blank and the next run will pick it up.");
        }

        sb.Append(nl).Append(nl);
        sb.Append(saved
            ? "The spreadsheet was saved with every result up to that point."
            : "The spreadsheet could NOT be saved. The run log has every result.");
        return sb.ToString();
    }

    /// <summary>
    /// Replaces the VB6 CheckExcel step (which offered to close whatever Excel workbook you had open):
    /// only checks whether THIS file is in use, and asks you to close it.
    /// </summary>
    private void WaitUntilFileIsFree(string path)
    {
        while (true)
        {
            try
            {
                using (new FileStream(path, FileMode.Open, FileAccess.ReadWrite, FileShare.None)) { }
                return;
            }
            catch (UnauthorizedAccessException)
            {
                throw new IOException($"{path} is read-only, or you don't have permission to change it.");
            }
            catch (IOException)
            {
                string message = $"{Path.GetFileName(path)} is open in another program (probably Excel).{Environment.NewLine}{Environment.NewLine}" +
                                 "Close it there, then click Retry.";
                if (!_op.AskRetry(message))
                    throw new OperationCanceledException("Cancelled: the spreadsheet was open in another program.");
            }
        }
    }

    private string BackUp(string path)
    {
        Directory.CreateDirectory(_backupFolder);
        string stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
        string target = Path.Combine(_backupFolder, $"{Path.GetFileNameWithoutExtension(path)}.{stamp}{Path.GetExtension(path)}");
        File.Copy(path, target, overwrite: true);
        return target;
    }
}
