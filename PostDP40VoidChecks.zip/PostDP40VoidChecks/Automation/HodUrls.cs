namespace PostDP40VoidChecks;

internal enum HodVersion
{
    ZHod,
    NewHod,
    OldHod,
}

/// <summary>VB6 HOD_Version_Change: picks the HOD launch URL for the chosen HOD version.</summary>
internal static class HodUrls
{
    private const string OldHodPath = "http://sdmvs/hod9/";
    private const string NewHodPath = "http://hodpilot.mf.adp.com/HOD/SAND/";
    private const string ZHodPath = "http://sand.hod.mf.adp.com/HOD/";

    /// <summary>
    /// Keeps the page variant that's in the current URL (ADPSDTECH or ADPCAVIEW; otherwise ADPSD)
    /// and swaps in the path for the chosen version, the same way the VB6 code did.
    /// </summary>
    public static string For(HodVersion version, string currentUrl)
    {
        string upper = VbCompat.TU(currentUrl);
        string page = "ADPSD";
        if (upper.Contains("ADPSDTECH")) page = "ADPSDTECH";
        if (upper.Contains("ADPCAVIEW")) page = "ADPCAVIEW";

        return version switch
        {
            HodVersion.OldHod => OldHodPath + page + ".html",
            HodVersion.NewHod => NewHodPath + page + ".jnlp",
            _ => ZHodPath + page + ".jnlp",
        };
    }
}
