using System;

namespace PostDP40VoidChecks;

/// <summary>
/// The TOPS screen flows: sign-on (VB6 Logon_Click) and the DP40 void/stop post (VB6 PostDP40).
/// Screen positions, literals, keys and waits are copied from the VB6 code; comments note the original names.
/// </summary>
internal sealed class TopsAutomation
{
    public const string MainMenuTitle = "T A X / F I N A N C I A L  S E R V I C E S";   // row 5, col 20, len 42
    private const string WelcomeBanner = "WELCOME TO THE TAX SERVICES NETWORK";
    private const string CicsWelcome = "Welcome to the San Dimas CICS/TS";              // row 1, col 2, len 32
    private const string CicsSignon = "Signon to CICS";                                 // row 1, col 29, len 19 (trimmed)
    private const string DeptMenuTitle = "ADP SAN DIMAS DEPARTMENT AND GROUP SELECTION MENU"; // row 1, col 17, len 49
    private const string Dp40RequestScreen = "DPI4000(DPI4001)";
    private const string Dpi1101 = "DPI1100(DPI1101)";
    private const string Dpi1103 = "DPI1100(DPI1103)";
    private const string Dpi1105 = "DPI1100(DPI1105)";

    private readonly HostSession _host;
    private readonly IOperator _op;

    // VB6 module-level Header$. ReturnToMainMenu checks it BEFORE pressing anything, so a row that
    // starts at the main menu doesn't get an extra PF15. Keep it across rows and runs, like the original.
    private string _lastHeader = "";

    public TopsAutomation(HostSession host, IOperator op)
    {
        _host = host;
        _op = op;
    }

    /// <summary>True once the Enter that submits the current row's DP40 request has been sent.</summary>
    public bool PostSubmitted { get; private set; }

    // =================================================================== sign-on (VB6 Logon_Click)

    public void SignOn(string session, string userId, string password)
    {
        try
        {
            if (!_host.LoggedOn)
            {
                _host.Connect(session);
                _op.Log($"Attached to HOD session {session}.");
            }

            // Wait for the Tax Services Network welcome screen, or the TOPS main menu if already signed on.
            string f1 = "", f2 = "", f3 = "";
            _host.WaitUntil("the TAX SERVICES NETWORK welcome screen (or the TOPS main menu)", () =>
            {
                _host.Pause(0.2);
                f1 = _host.GetScreen(1, 2, 70);
                f2 = _host.GetScreen(2, 2, 70);
                f3 = _host.GetScreen(5, 2, 75);
                return f1.Contains(WelcomeBanner) || f2.Contains(WelcomeBanner) || f3.Contains(MainMenuTitle);
            });

            if (f3.Contains(MainMenuTitle))
            {
                _op.Log("Already at the TOPS main menu.");
                return;
            }

            _host.TypeAndVerify("CICSA", 4, 1);
            _host.SendKey("@E", "Sign-on: go to CICSA.");

            _host.WaitUntil("the San Dimas CICS/TS welcome screen", () =>
            {
                _host.Pause(0.05);
                return _host.GetScreen(1, 2, 32) == CicsWelcome;
            });

            _host.Pause(0.5);
            _host.SendKey("@C", "Sign-on: clear the CICS welcome screen.");
            _host.Pause(0.5);

            _host.TypeAndVerify("TAX3", 1, 1);
            _host.SendKey("@E", "Sign-on: start TAX3.");

            _host.WaitUntil("the Signon to CICS screen", () =>
            {
                _host.Pause(0.05);
                return VbCompat.TrimSpaces(_host.GetScreen(1, 29, 19)) == CicsSignon;
            });

            _host.TypeAndVerify(userId, 10, 26);
            _host.TypeAndVerify(password, 11, 26);
            _host.SendKey("@E", "Sign-on: submit user ID and password.");

            string title = "", menu = "";
            _host.WaitUntil("the department/group selection menu or the TOPS main menu (check the user ID and password)", () =>
            {
                _host.Pause(0.05);
                title = _host.GetScreen(1, 17, 49);
                menu = _host.GetScreen(5, 20, 42);
                return title == DeptMenuTitle || menu == MainMenuTitle;
            });

            if (title == DeptMenuTitle)
            {
                _host.SetCursor(6, 10);
                _host.SendKey("@E", "Sign-on: pick the first department/group entry.");
            }

            _op.Log("Signed on to TOPS.");
        }
        catch
        {
            // Detach so the next Connect click starts clean. (The VB6 version stayed "logged on" after a
            // failed attempt and never re-attached.) This doesn't sign off CICS.
            _host.Disconnect();
            _lastHeader = "";
            throw;
        }
    }

    // =================================================================== DP40 post (VB6 PostDP40)

    /// <summary>
    /// Posts one void/stop request on DP40. <paramref name="recordResult"/> is called with the TOPS message
    /// (row 22) as soon as it is known, before returning to the main menu, the same point at which the VB6 code
    /// wrote column T.
    /// </summary>
    public void PostVoidOrStop(VoidCheckRow r, Action<string> recordResult)
    {
        PostSubmitted = false;

        // 1. From the TOPS main menu, start DP40.
        ReturnToMainMenu();
        _host.TypeAndVerify("DP40", 17, 51);
        _host.SendKey("@E", "Open DP40 from the TOPS main menu.");

        // 2. DP40 request screen: fill the five fields.
        WaitForScreen(Dp40RequestScreen, "F15=Main Menu", 24, 39, 13);
        _host.TypeAndVerify(r.DisbAcct, 7, 44);
        _host.TypeAndVerify(r.CheckNumber, 8, 44);
        _host.TypeAndVerify(r.AmountText, 9, 44);
        _host.TypeAndVerify(r.RequestType, 10, 44);
        _host.TypeAndVerify(r.LiabilityType, 12, 44);

        long keysBefore = _host.KeysSent;
        try
        {
            _host.SendKey("@E", $"SUBMIT row {r.Row}: {r.Describe()}.");
        }
        finally
        {
            PostSubmitted = _host.KeysSent > keysBefore;
        }

        // 3. Wait for TOPS to answer on row 22. Any "...ENTER..." prompt on row 5 gets an Enter.
        string message = "", heading = "";
        _host.WaitUntil("a TOPS message on row 22 after submitting", () =>
        {
            _host.Pause(0.05);
            message = VbCompat.TrimSpaces(_host.GetScreen(22, 15, 65));
            heading = VbCompat.TrimSpaces(_host.GetScreen(2, 2, 16));
            if (VbCompat.TU(_host.GetScreen(5, 1, 80)).Contains("ENTER"))
            {
                _host.Pause(0.5);
                _host.SendKey("@E", "TOPS shows an ENTER prompt on row 5; answer it.");
                _host.Pause(0.5);
            }
            return message.Length > 0 || heading == Dpi1101;
        });

        if (heading == Dpi1101)
            message = LegacyFrequencyBranch(r, message);

        // 4. Record the result, then PF15 back to the main menu.
        recordResult(message);

        if (_op.CheckpointsEnabled &&
            !_host.Confirm($"Posting result = {message}{Environment.NewLine}{Environment.NewLine}" +
                           "OK = continue      Cancel = stop after this row"))
        {
            _op.RequestStopAfterCurrentRow();
        }

        _host.SendKey("@f", "Back to the TOPS main menu.");
        ReturnToMainMenu();
    }

    /// <summary>
    /// Carried over unchanged from the VB6 code. It came from an older "adjust SIT deposit frequency on DP40"
    /// program: it treats column B as a deposit frequency (MN.../QT...) instead of a check number, so for a real
    /// check number it shows "INVALID FREQUENCY--" and records "INVALID FREQUENCY" + the check number.
    /// It only runs if TOPS shows DPI1100(DPI1101) after the DP40 post.
    /// </summary>
    private string LegacyFrequencyBranch(VoidCheckRow r, string message)
    {
        _op.Log($"Row {r.Row}: TOPS went to {Dpi1101}; running the legacy frequency steps from the VB6 code.");
        _host.TypeAndVerify("DP40", 23, 15);

        string freq = r.CheckNumber;
        bool monthly = freq.StartsWith("MN", StringComparison.Ordinal);
        bool quarterly = freq.StartsWith("QT", StringComparison.Ordinal);
        if (!monthly && !quarterly)
        {
            _host.Notify("INVALID FREQUENCY--");
            return "INVALID FREQUENCY" + freq;
        }

        if (monthly) _host.TypeAndVerify("2", 15, 8);
        if (quarterly) _host.TypeAndVerify("2", 15, 61);
        _host.SendKey("@E", "Legacy DPI1100 step 1.");

        string heading;
        (message, heading) = WaitForMessageOrHeading(Dpi1103);
        if (heading != Dpi1103) return message;

        _host.TypeAndVerify("01", 13, 26);
        _host.SendKey("@E", "Legacy DPI1100 step 2.");

        (message, heading) = WaitForMessageOrHeading(Dpi1105);
        if (heading != Dpi1105) return message;

        _host.TypeAndVerify("DP40", 23, 15);
        _host.SendKey("@E", "Legacy DPI1100 step 3.");

        (message, _) = WaitForMessageOrHeading(null);
        return message;
    }

    // =================================================================== waits

    /// <summary>
    /// VB6 Waits4MM: if the last header seen isn't the main menu, press PF15 and look again until it is.
    /// </summary>
    private void ReturnToMainMenu()
    {
        if (_lastHeader == MainMenuTitle) return;

        _host.WaitUntil("the TOPS main menu", () =>
        {
            _host.Pause(0.05);
            _host.SendKey("@f", "PF15 to get back to the TOPS main menu.");
            _lastHeader = _host.GetScreen(5, 20, 42);
            return _lastHeader == MainMenuTitle;
        });
    }

    /// <summary>
    /// VB6 Waits1: wait until the screen title (row 2) and footer match, or the message line contains "NOT".
    /// As in the original, a "NOT" message doesn't stop the flow.
    /// </summary>
    private void WaitForScreen(string heading, string footing, int footRow, int footCol, int footLen)
    {
        string footingUpper = VbCompat.TU(footing);
        string message = "";
        _lastHeader = "";

        _host.WaitUntil($"screen {heading}", () =>
        {
            _host.Pause(0.05);
            _lastHeader = VbCompat.TrimSpaces(_host.GetScreen(2, 2, 18));
            string footer = _host.GetScreen(footRow, footCol, footLen);
            message = VbCompat.TrimSpaces(_host.GetScreen(22, 14, 64));
            return (_lastHeader == heading && VbCompat.TU(footer) == footingUpper) || message.Contains("NOT");
        });

        if (_lastHeader != heading)
            _op.Log($"Expected {heading} but TOPS says: {message}");
    }

    /// <summary>Wait until row 22 shows a message, or (if given) the row 2 title equals <paramref name="heading"/>.</summary>
    private (string Message, string Heading) WaitForMessageOrHeading(string? heading)
    {
        string message = "", seen = "";
        _host.WaitUntil(heading is null ? "a TOPS message on row 22" : $"a TOPS message or screen {heading}", () =>
        {
            _host.Pause(0.05);
            message = VbCompat.TrimSpaces(_host.GetScreen(22, 15, 65));
            seen = VbCompat.TrimSpaces(_host.GetScreen(2, 2, 16));
            return message.Length > 0 || (heading is not null && seen == heading);
        });
        return (message, seen);
    }
}
