using System;
using System.Globalization;
using System.Text;

namespace PostDP40VoidChecks;

/// <summary>Small helpers that reproduce the VB6 program's string and number handling exactly.</summary>
internal static class VbCompat
{
    /// <summary>VB6 TU$: Trim$(UCase$(s)). VB's Trim only strips spaces.</summary>
    public static string TU(string? s) => (s ?? "").ToUpperInvariant().Trim(' ');

    /// <summary>VB6 Trim$ / LTrim$(RTrim$()): spaces only.</summary>
    public static string TrimSpaces(string s) => s.Trim(' ');

    /// <summary>
    /// VB6 NumVal: keep only digits and '.', a TRAILING '-' makes it negative (mainframe style, "125.00-"),
    /// then Val(). A leading '-' is dropped, exactly like the original. Result is rounded to 4 places
    /// because the VB variable was Currency.
    /// </summary>
    public static decimal NumVal(string? text)
    {
        string num = (text ?? "").Trim(' ');
        var kept = new StringBuilder();
        foreach (char c in num)
        {
            if (char.IsAsciiDigit(c) || c == '.') kept.Append(c);
        }
        string temp = kept.ToString();
        if (num.EndsWith('-')) temp = "-" + temp;
        return Math.Round(Val(temp), 4, MidpointRounding.ToEven);
    }

    /// <summary>VB6 Val(): the leading numeric part of the string, '.' as the decimal point.</summary>
    public static decimal Val(string s)
    {
        int i = 0;
        bool negative = false;
        if (i < s.Length && (s[i] == '-' || s[i] == '+'))
        {
            negative = s[i] == '-';
            i++;
        }

        var digits = new StringBuilder();
        bool seenDot = false;
        for (; i < s.Length; i++)
        {
            char c = s[i];
            if (char.IsAsciiDigit(c)) digits.Append(c);
            else if (c == '.' && !seenDot) { seenDot = true; digits.Append(c); }
            else break;
        }

        string d = digits.ToString();
        if (d.Length == 0 || d == ".") return 0m;
        if (d.StartsWith('.')) d = "0" + d;
        if (d.EndsWith('.')) d += "0";

        try
        {
            decimal value = decimal.Parse(d, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture);
            return negative ? -value : value;
        }
        catch (OverflowException)
        {
            return 0m; // absurdly long number: treat as not a number, so the row is skipped
        }
    }

    /// <summary>How VB6 turned the Currency amount into the text it typed on the screen ("125.5", "100", "0.05").</summary>
    public static string CurrencyText(decimal value) => value.ToString("0.####", CultureInfo.InvariantCulture);

    /// <summary>The column T text: Message$ + "-- " + Date$ + "  " + Time$  (Date$ = mm-dd-yyyy, Time$ = hh:mm:ss 24h).</summary>
    public static string ResultStamp(string message, DateTime now) =>
        message + "-- " + now.ToString("MM-dd-yyyy", CultureInfo.InvariantCulture) + "  " +
        now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
}
