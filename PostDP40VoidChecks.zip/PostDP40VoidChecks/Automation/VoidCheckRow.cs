namespace PostDP40VoidChecks;

/// <summary>
/// One spreadsheet row, read the way the VB6 Process_Sheet loop read it:
///   A = Disb Acct, B = Check Number, C = Check Amount, D = Void (1) / Stop (2), E = Federal (1) / State (2).
/// Text values are trimmed and upper-cased (VB TU$); the amount goes through NumVal.
/// </summary>
internal sealed record VoidCheckRow(
    int Row,
    string DisbAcct,
    string CheckNumber,
    decimal Amount,
    string AmountText,
    string RequestType,
    string LiabilityType,
    bool HasErrorCell,
    bool IsBlank)
{
    public static VoidCheckRow Read(ExcelWorkbook book, int row)
    {
        CellValue a = book.Read(row, 1);
        CellValue b = book.Read(row, 2);
        CellValue c = book.Read(row, 3);
        CellValue d = book.Read(row, 4);
        CellValue e = book.Read(row, 5);

        decimal amount = VbCompat.NumVal(c.Text);
        bool blank = string.IsNullOrWhiteSpace(a.Text + b.Text + c.Text + d.Text + e.Text);

        return new VoidCheckRow(
            row,
            VbCompat.TU(a.Text),
            VbCompat.TU(b.Text),
            amount,
            VbCompat.CurrencyText(amount),
            VbCompat.TU(d.Text),
            VbCompat.TU(e.Text),
            a.IsError || b.IsError || c.IsError || d.IsError || e.IsError,
            blank);
    }

    /// <summary>
    /// Returns null if the row should be posted, otherwise why not. Same rules as VB6
    /// (Len(A) &lt;= 2, Len(B) &lt;= 8, amount &lt;&gt; 0, Len(D) = 1, Len(E) = 1), except that A and B
    /// may no longer be blank, and cells holding Excel errors are refused.
    /// </summary>
    public string? Validate()
    {
        if (HasErrorCell) return "one of columns A-E holds an Excel error value";
        if (DisbAcct.Length is 0 or > 2) return $"column A (Disb Acct) must be 1-2 characters, found \"{DisbAcct}\"";
        if (CheckNumber.Length is 0 or > 8) return $"column B (Check Number) must be 1-8 characters, found \"{CheckNumber}\"";
        if (Amount == 0) return "column C (Check Amount) is blank, zero or not a number";
        if (RequestType.Length != 1) return $"column D must be one character (1 = Void, 2 = Stop), found \"{RequestType}\"";
        if (LiabilityType.Length != 1) return $"column E must be one character (1 = Federal, 2 = State), found \"{LiabilityType}\"";
        return null;
    }

    public string Describe() =>
        $"disb acct {DisbAcct}, check {CheckNumber}, amount {AmountText}, " +
        $"{Kind(RequestType, "Void", "Stop")}, {Kind(LiabilityType, "Federal", "State")}";

    private static string Kind(string code, string one, string two) => code switch
    {
        "1" => one,
        "2" => two,
        _ => "code " + code,
    };
}
