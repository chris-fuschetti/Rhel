using System;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;

namespace PostDP40VoidChecks;

/// <summary>A cell's value as text, and whether Excel holds an error (#N/A, #VALUE! ...) there.</summary>
internal readonly record struct CellValue(string Text, bool IsError);

/// <summary>
/// The spreadsheet, opened in a private, hidden Excel instance through late-bound COM (no Office interop
/// assemblies needed, works with any installed Excel version). Must be used on one STA thread.
/// </summary>
internal sealed class ExcelWorkbook : IDisposable
{
    private const int XlUp = -4162;

    private object? _app;
    private object? _workbook;
    private object? _sheet;

    private ExcelWorkbook(string path) => FilePath = path;

    public string FilePath { get; }
    public string SheetName { get; private set; } = "";

    private dynamic Sheet => _sheet ?? throw new ObjectDisposedException(nameof(ExcelWorkbook));
    private dynamic Workbook => _workbook ?? throw new ObjectDisposedException(nameof(ExcelWorkbook));

    /// <summary>Opens the workbook and activates its first sheet (the VB6 code only ever processed sheet 1).</summary>
    public static ExcelWorkbook Open(string path)
    {
        var book = new ExcelWorkbook(path);
        try
        {
            Type excelType = Type.GetTypeFromProgID("Excel.Application")
                ?? throw new InvalidOperationException("Microsoft Excel isn't installed on this PC (Excel.Application isn't registered).");

            dynamic app = Activator.CreateInstance(excelType)
                ?? throw new InvalidOperationException("Excel couldn't be started.");
            book._app = app;
            app.Visible = false;
            app.DisplayAlerts = false;

            dynamic workbook = app.Workbooks.Open(path);
            book._workbook = workbook;
            if ((bool)workbook.ReadOnly)
                throw new IOException($"Excel opened {path} read-only (someone may have it open), so results couldn't be saved. Close it everywhere and try again.");

            dynamic sheet = workbook.Worksheets[1];
            book._sheet = sheet;
            sheet.Activate();
            book.SheetName = (string)sheet.Name;
            return book;
        }
        catch
        {
            book.Dispose();
            throw;
        }
    }

    /// <summary>VB6: .Cells(65530, column).End(xlUp).Row</summary>
    public int LastUsedRow(int column)
    {
        try
        {
            return (int)Sheet.Cells[65530, column].End[XlUp].Row;
        }
        catch (Exception)
        {
            // Fallback: scan up from the bottom of the used range.
            dynamic used = Sheet.UsedRange;
            int bottom = Math.Min(65530, (int)used.Row + (int)used.Rows.Count - 1);
            for (int row = bottom; row >= 1; row--)
            {
                object? value = Sheet.Cells[row, column].Value2;
                if (value is not null) return row;
            }
            return 1;
        }
    }

    public CellValue Read(int row, int column)
    {
        object? value = Sheet.Cells[row, column].Value2;
        return value switch
        {
            null => new CellValue("", false),
            string s => new CellValue(s, false),
            double d => new CellValue(d.ToString(CultureInfo.InvariantCulture), false),
            bool b => new CellValue(b ? "True" : "False", false),
            int => new CellValue("#ERROR", true), // Value2 returns Excel error values (#N/A, #VALUE!...) as Int32
            _ => new CellValue(Convert.ToString(value, CultureInfo.InvariantCulture) ?? "", false),
        };
    }

    public void Write(int row, int column, string text)
    {
        Sheet.Cells[row, column].Value2 = text;
    }

    public void Save()
    {
        Workbook.Save();
    }

    /// <summary>Closes the workbook WITHOUT saving (call Save first), quits Excel and releases COM references.</summary>
    public void Dispose()
    {
        if (_workbook is not null)
        {
            try { ((dynamic)_workbook).Close(false); } catch { /* already closed */ }
        }
        if (_app is not null)
        {
            try { ((dynamic)_app).Quit(); } catch { /* already gone */ }
        }

        Release(ref _sheet);
        Release(ref _workbook);
        Release(ref _app);

        // Collect the temporary Range RCWs so EXCEL.EXE actually exits.
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        GC.WaitForPendingFinalizers();
    }

    private static void Release(ref object? comObject)
    {
        if (comObject is not null && Marshal.IsComObject(comObject))
        {
            try { Marshal.FinalReleaseComObject(comObject); } catch { /* ignore */ }
        }
        comObject = null;
    }
}
