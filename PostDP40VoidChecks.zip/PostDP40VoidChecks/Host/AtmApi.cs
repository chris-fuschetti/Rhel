using System.Runtime.InteropServices;

namespace PostDP40VoidChecks;

/// <summary>
/// P/Invoke declarations for ATMAPI32.DLL, matching the VB6 "Private Declare Function" lines one for one.
/// VB6 type mapping: Long -> int (32-bit), Integer -> short (16-bit), ByVal String -> ANSI char*.
/// The DLL is 32-bit, so this only works in an x86 process (see the .csproj).
/// Only the functions the program actually calls are declared.
/// </summary>
internal static class AtmApi
{
    private const string Dll = "ATMAPI32.DLL";

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLRegisterClient(int hWnd, short nType);

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLUnregisterClient(int hWnd);

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLConnectSession(int hWnd, string session);

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLDisconnectSession(int hWnd);

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLSendKey(int hWnd, string key);

    /// <summary>Copies <paramref name="length"/> characters from the screen into <paramref name="buffer"/>.</summary>
    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLGetString(int hWnd, short row, short column, [In, Out] byte[] buffer, short length);

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLSendString(int hWnd, short row, short column, string text);

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLWaitHostQuiet(int hWnd, short settleTime, short timeout);

    [DllImport(Dll, CharSet = CharSet.Ansi, CallingConvention = CallingConvention.StdCall)]
    public static extern int UTLSetCursorLocation(int hWnd, short row, short column);

    /// <summary>The VB6 code used App.ThreadID as the client "handle"; this is the same value for the calling thread.</summary>
    [DllImport("kernel32.dll")]
    public static extern uint GetCurrentThreadId();
}
