using System;
using System.Diagnostics;
using System.Text;
using System.Windows.Forms;

namespace PostDP40VoidChecks;

/// <summary>
/// The HOD session through ATMAPI32.DLL: the VB6 "HOD CODE" section (HOD_Logon, HOD_LogOff, SendKeys,
/// GetScreen2, PutScreen, SetCursorLocation, Delays, Timerx), plus timeouts and an abort switch.
///
/// Every method must be called on the same thread (the StaWorker thread). The DLL client "handle"
/// is that thread's ID, exactly as the VB6 code used App.ThreadID.
/// </summary>
internal sealed class HostSession
{
    private const short SettleTime = 300;
    private const short ConnectTimeout = 60;

    private readonly IOperator _op;

    // VB6: Dim tmpString As String * 100. Reused across calls, like the original.
    private readonly byte[] _screenBuffer = new byte[101];

    private int _handle;
    private bool _registered;
    private bool _connected;
    private volatile bool _loggedOn;
    private long _operatorTicks; // time spent in checkpoint dialogs; not counted against screen timeouts

    public HostSession(IOperator op) => _op = op;

    /// <summary>VB6 HOD_Logged_On.</summary>
    public bool LoggedOn => _loggedOn;

    /// <summary>Number of keys actually sent to the host so far (used to tell whether a post was submitted).</summary>
    public long KeysSent { get; private set; }

    // ---------------------------------------------------------------- connect / disconnect

    /// <summary>VB6 HOD_Logon: register, connect to session A/B, wait for the host to settle.</summary>
    public void Connect(string session)
    {
        try
        {
            _handle = unchecked((int)AtmApi.GetCurrentThreadId());
            int rc = AtmApi.UTLRegisterClient(_handle, 1);
            _registered = true;
            _op.Log($"UTLRegisterClient rc={rc}");

            rc = AtmApi.UTLConnectSession(_handle, session);
            _connected = true;
            _op.Log($"UTLConnectSession(\"{session}\") rc={rc}");

            rc = AtmApi.UTLWaitHostQuiet(_handle, SettleTime, ConnectTimeout);
            _op.Log($"UTLWaitHostQuiet rc={rc}");

            _loggedOn = true;
        }
        catch (DllNotFoundException ex)
        {
            throw new InvalidOperationException(
                "Couldn't load ATMAPI32.DLL. It has to be installed on this PC (the VB6 version needed it too) " +
                "and be on the PATH, in Windows\\SysWOW64, or next to this program." + Environment.NewLine + ex.Message, ex);
        }
        catch (BadImageFormatException ex)
        {
            throw new InvalidOperationException(
                "ATMAPI32.DLL couldn't be loaded into this process. The program must be built for x86 (32-bit)." +
                Environment.NewLine + ex.Message, ex);
        }
    }

    /// <summary>VB6 HOD_LogOff: unregister and disconnect (same order as the original). Safe to call any time.</summary>
    public void Disconnect()
    {
        if (!_loggedOn && !_registered && !_connected) return;
        try { if (_registered) AtmApi.UTLUnregisterClient(_handle); }
        catch (Exception ex) { _op.Log("UTLUnregisterClient failed: " + ex.Message); }
        try { if (_connected) AtmApi.UTLDisconnectSession(_handle); }
        catch (Exception ex) { _op.Log("UTLDisconnectSession failed: " + ex.Message); }
        _registered = false;
        _connected = false;
        _loggedOn = false;
        _op.Log("Detached from the HOD session.");
    }

    // ---------------------------------------------------------------- screen primitives

    /// <summary>VB6 GetScreen2(row, col, len).</summary>
    public string GetScreen(int row, int column, int length)
    {
        AtmApi.UTLGetString(_handle, (short)row, (short)column, _screenBuffer, (short)length);
        return Encoding.Latin1.GetString(_screenBuffer, 0, length);
    }

    /// <summary>VB6 PutScreen(text, row, col, len).</summary>
    public void PutString(string text, int row, int column) =>
        AtmApi.UTLSendString(_handle, (short)row, (short)column, text);

    /// <summary>VB6 SetCursorLocation(row, col).</summary>
    public void SetCursor(int row, int column) =>
        AtmApi.UTLSetCursorLocation(_handle, (short)row, (short)column);

    /// <summary>
    /// VB6 SendKeys: same delays as the original (0.2 s either side, plus 2 s either side of PF15/PF5),
    /// and the same "OK to press ...?" checkpoint. Cancel at the checkpoint stops the run before the key is sent.
    /// </summary>
    public void SendKey(string key, string why)
    {
        bool slowKey = key is "@f" or "@5";
        if (slowKey) Pause(2.0);

        if (_op.CheckpointsEnabled &&
            !Confirm($"OK to press {KeyName(key)} ({key})?{Environment.NewLine}{Environment.NewLine}{why}" +
                     $"{Environment.NewLine}{Environment.NewLine}OK = press it      Cancel = stop"))
        {
            throw new OperatorStoppedException();
        }

        Pause(0.2);
        AtmApi.UTLSendKey(_handle, key);
        KeysSent++;
        Pause(0.2);

        if (slowKey) Pause(2.0);
    }

    /// <summary>
    /// VB6 Delays(value, row, col): write zeros over the field until they read back, then write the value
    /// until it reads back. An empty value does nothing, as in the original.
    /// </summary>
    public void TypeAndVerify(string value, int row, int column)
    {
        if (value.Length == 0) return;

        string zeros = new string('0', value.Length);
        WaitUntil($"the field at row {row}, column {column} to accept input", () =>
        {
            Pause(0.05);
            PutString(zeros, row, column);
            return GetScreen(row, column, zeros.Length) == zeros;
        });

        WaitUntil($"the field at row {row}, column {column} to show the typed value", () =>
        {
            Pause(0.05);
            PutString(value, row, column);
            return GetScreen(row, column, value.Length) == value;
        });
    }

    // ---------------------------------------------------------------- waiting

    /// <summary>
    /// VB6 Timerx(seconds). Keeps this thread's message queue moving while it waits (the VB6 version called
    /// DoEvents in the same loop), and honours Abort.
    /// </summary>
    public void Pause(double seconds)
    {
        long until = Stopwatch.GetTimestamp() + (long)(seconds * Stopwatch.Frequency);
        do
        {
            Application.DoEvents();
            if (_op.AbortToken.WaitHandle.WaitOne(10))
                throw new OperationCanceledException("Stopped by the operator.");
        }
        while (Stopwatch.GetTimestamp() < until);
    }

    /// <summary>
    /// Repeats <paramref name="poll"/> until it returns true. This replaces the VB6 "Do Until ... Loop" waits,
    /// which had no limit; here the limit is the Screen timeout box (0 = wait forever). Time spent answering
    /// checkpoint dialogs doesn't count.
    /// </summary>
    public void WaitUntil(string waitingFor, Func<bool> poll)
    {
        TimeSpan limit = _op.ScreenTimeout;
        var clock = Stopwatch.StartNew();
        long operatorTicksAtStart = _operatorTicks;

        while (!poll())
        {
            if (limit <= TimeSpan.Zero) continue;
            TimeSpan hostTime = clock.Elapsed - TimeSpan.FromTicks(_operatorTicks - operatorTicksAtStart);
            if (hostTime > limit)
                throw new HostTimeoutException(waitingFor, limit, DescribeScreen());
        }
    }

    // ---------------------------------------------------------------- operator dialogs (timed)

    public bool Confirm(string message)
    {
        var clock = Stopwatch.StartNew();
        try { return _op.Confirm(message); }
        finally { _operatorTicks += clock.Elapsed.Ticks; }
    }

    public void Notify(string message)
    {
        var clock = Stopwatch.StartNew();
        try { _op.Notify(message); }
        finally { _operatorTicks += clock.Elapsed.Ticks; }
    }

    // ---------------------------------------------------------------- helpers

    /// <summary>Title, menu and message lines only, for timeout reports. Never the sign-on field rows.</summary>
    private string DescribeScreen()
    {
        try
        {
            var sb = new StringBuilder();
            foreach (int row in new[] { 1, 2, 5, 22, 23, 24 })
                sb.AppendLine($"  {row,2}: {GetScreen(row, 1, 80).Replace('\0', ' ').TrimEnd()}");
            return sb.ToString().TrimEnd();
        }
        catch
        {
            return "";
        }
    }

    private static string KeyName(string key) => key switch
    {
        "@E" => "Enter",
        "@C" => "Clear",
        "@f" => "PF15",
        "@5" => "PF5",
        _ => key,
    };
}
