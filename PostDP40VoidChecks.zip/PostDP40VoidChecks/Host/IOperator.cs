using System;
using System.Threading;

namespace PostDP40VoidChecks;

/// <summary>
/// The person at the keyboard, as seen from the automation thread. MainForm implements this;
/// every call is safe to make from the worker thread.
/// </summary>
internal interface IOperator
{
    /// <summary>The "Checkpoints" box: confirm before every key sent to the host. Read live, so it can be toggled mid-run.</summary>
    bool CheckpointsEnabled { get; }

    /// <summary>How long to wait for any one screen condition. Zero means wait forever (the VB6 behaviour).</summary>
    TimeSpan ScreenTimeout { get; }

    /// <summary>Signalled when the operator clicks Abort (or closes the program mid-run).</summary>
    CancellationToken AbortToken { get; }

    /// <summary>OK/Cancel question. Returns true for OK. Blocks the worker until answered.</summary>
    bool Confirm(string message);

    /// <summary>OK-only message box. Blocks the worker until dismissed.</summary>
    void Notify(string message);

    /// <summary>Retry/Cancel question. Returns true for Retry.</summary>
    bool AskRetry(string message);

    /// <summary>Finish the row in progress, then stop the batch.</summary>
    void RequestStopAfterCurrentRow();

    /// <summary>Adds a line to the on-screen log and the run log file. Never pass a password here.</summary>
    void Log(string message);

    /// <summary>Updates the status line (the VB6 MessageLabel).</summary>
    void Status(string message);
}

/// <summary>A screen condition did not appear within the configured timeout.</summary>
internal sealed class HostTimeoutException : Exception
{
    public HostTimeoutException(string waitingFor, TimeSpan limit, string screen)
        : base($"Timed out after {limit.TotalSeconds:0} seconds waiting for {waitingFor}."
               + (screen.Length > 0 ? Environment.NewLine + Environment.NewLine + "Screen at the time:" + Environment.NewLine + screen : ""))
    {
    }
}

/// <summary>The operator clicked Cancel at a checkpoint.</summary>
internal sealed class OperatorStoppedException : OperationCanceledException
{
    public OperatorStoppedException() : base("Stopped at a checkpoint.") { }
}
