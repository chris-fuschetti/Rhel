using System;
using System.Globalization;
using System.IO;
using System.Text.Json;

namespace PostDP40VoidChecks;

internal static class AppPaths
{
    public static string Root { get; } = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PostDP40VoidChecks");

    public static string LogFolder => Path.Combine(Root, "logs");
    public static string BackupFolder => Path.Combine(Root, "backups");
    public static string SettingsFile => Path.Combine(Root, "settings.json");
}

/// <summary>Remembered between runs. Credentials are never stored, and Checkpoints always starts ON.</summary>
internal sealed class AppSettings
{
    public string HodVersion { get; set; } = "zHOD";
    public string HodUrl { get; set; } = "http://sdmvs/hod9/ADPSD.html";
    public string Session { get; set; } = "A";
    public string SourceFile { get; set; } = @"c:\temp\VOID_STOP_CHECK_List.xlsx";
    public int SaveEvery { get; set; } = 20;
    public int TimeoutSeconds { get; set; } = 120;

    public static AppSettings Load(string path)
    {
        try
        {
            if (File.Exists(path))
                return JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(path)) ?? new AppSettings();
        }
        catch
        {
            // Unreadable settings: fall back to defaults.
        }
        return new AppSettings();
    }

    public void Save(string path)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
        }
        catch
        {
            // Not worth interrupting the operator over.
        }
    }
}

/// <summary>Daily run log file. Thread-safe. Never write the password here.</summary>
internal sealed class RunLog
{
    private readonly object _gate = new();
    private readonly string _folder;

    public RunLog(string folder)
    {
        _folder = folder;
        try { Directory.CreateDirectory(folder); } catch { /* logged to screen only */ }
    }

    public string CurrentPath =>
        Path.Combine(_folder, $"PostDP40-{DateTime.Now.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)}.log");

    public void Write(string message)
    {
        lock (_gate)
        {
            try
            {
                File.AppendAllText(CurrentPath,
                    $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)}  {message}{Environment.NewLine}");
            }
            catch
            {
                // Logging must never stop a run.
            }
        }
    }
}
