using System;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PostDP40VoidChecks;

/// <summary>
/// One long-lived STA thread that runs every HOD and Excel call, one job at a time.
/// ATMAPI32 identifies its client by thread ID, and Excel COM wants a single STA thread, so everything
/// happens here. The thread pumps its own message queue while idle (and HostSession.Pause pumps while
/// waiting), so it behaves like the VB6 UI thread did with DoEvents, without freezing the window.
/// </summary>
internal sealed class StaWorker : IDisposable
{
    private readonly BlockingCollection<Action> _queue = new();
    private readonly Thread _thread;

    public StaWorker(string name)
    {
        _thread = new Thread(Loop) { IsBackground = true, Name = name };
        _thread.SetApartmentState(ApartmentState.STA);
        _thread.Start();
    }

    public Task RunAsync(Action work)
    {
        var done = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        _queue.Add(() =>
        {
            try
            {
                work();
                done.SetResult();
            }
            catch (Exception ex)
            {
                done.SetException(ex);
            }
        });
        return done.Task;
    }

    private void Loop()
    {
        while (!_queue.IsCompleted)
        {
            Action? work;
            try
            {
                if (!_queue.TryTake(out work, 50))
                {
                    Application.DoEvents();
                    continue;
                }
            }
            catch (InvalidOperationException)
            {
                break; // CompleteAdding was called
            }
            work();
        }
    }

    public void Dispose()
    {
        _queue.CompleteAdding();
        _thread.Join(TimeSpan.FromSeconds(2));
    }
}
