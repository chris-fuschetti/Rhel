using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PostDP40VoidChecks;

/// <summary>
/// The window (VB6 FutaFixForm) and the IOperator the automation talks to.
/// All host and Excel work runs on _worker; this class only handles the UI.
/// </summary>
internal sealed class MainForm : Form, IOperator
{
    // --- Host On-Demand
    private readonly RadioButton _zHod = new() { Text = "zHOD", AutoSize = true };
    private readonly RadioButton _newHod = new() { Text = "New HOD", AutoSize = true };
    private readonly RadioButton _oldHod = new() { Text = "Old HOD", AutoSize = true };
    private readonly TextBox _hodUrl = new() { Anchor = AnchorStyles.Left | AnchorStyles.Right };
    private readonly TextBox _session = new() { MaxLength = 1, CharacterCasing = CharacterCasing.Upper, TextAlign = HorizontalAlignment.Center };
    private readonly Button _startHod = new() { Text = "Start HOD", AutoSize = true };

    // --- TOPS sign-on
    private readonly TextBox _userId = new();
    private readonly TextBox _password = new() { UseSystemPasswordChar = true };
    private readonly Button _connect = new() { Text = "Connect", AutoSize = true };

    // --- Spreadsheet and options
    private readonly TextBox _sourceFile = new() { Anchor = AnchorStyles.Left | AnchorStyles.Right };
    private readonly Button _browse = new() { Text = "Browse…", AutoSize = true };
    private readonly CheckBox _checkpoints = new() { Text = "Checkpoints (confirm before every key press)", AutoSize = true, Checked = true };
    private readonly NumericUpDown _saveEvery = new() { Minimum = 0, Maximum = 100000 };
    private readonly NumericUpDown _timeout = new() { Minimum = 0, Maximum = 3600 };

    // --- Actions and output
    private readonly Button _run = new() { Text = "Update per file", AutoSize = true };
    private readonly Button _stop = new() { Text = "Stop", AutoSize = true, Enabled = false };
    private readonly Button _saveNow = new() { Text = "Save now", AutoSize = true, Enabled = false };
    private readonly Button _exit = new() { Text = "Exit", AutoSize = true };
    private readonly Label _status = new() { AutoSize = true };
    private readonly TextBox _log = new() { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Dock = DockStyle.Fill };
    private readonly List<Label> _wrappingLabels = new();

    // --- Automation
    private readonly StaWorker _worker = new("HOD automation");
    private readonly RunLog _runLog = new(AppPaths.LogFolder);
    private readonly HostSession _host;
    private readonly TopsAutomation _tops;
    private readonly BatchRunner _batch;
    private readonly AppSettings _settings;

    private CancellationTokenSource _cts = new();
    private volatile bool _checkpointsOn = true;
    private volatile int _timeoutSeconds = 120;
    private volatile bool _stopAfterRow;
    private volatile bool _saveRequested;
    private bool _busy;
    private bool _batchRunning;
    private bool _closing;
    private bool _readyToClose;
    private DateTime _lastHodLaunch = DateTime.MinValue;

    public MainForm()
    {
        _host = new HostSession(this);
        _tops = new TopsAutomation(_host, this);
        _batch = new BatchRunner(_tops, this, AppPaths.BackupFolder);
        _settings = AppSettings.Load(AppPaths.SettingsFile);

        BuildLayout();
        WireEvents();
        ApplySettings();

        Log("Ready. Run log: " + _runLog.CurrentPath);
        Status("Start HOD, then Connect, then Update per file.");
    }

    // =====================================================================================  IOperator

    // Explicit, so the form exposes no extra public properties to the WinForms designer/analyzers.
    bool IOperator.CheckpointsEnabled => _checkpointsOn;

    TimeSpan IOperator.ScreenTimeout => TimeSpan.FromSeconds(_timeoutSeconds);

    CancellationToken IOperator.AbortToken => _cts.Token;

    public bool Confirm(string message) => (bool)Invoke(new Func<bool>(() =>
        MessageBox.Show(this, message, "Checkpoint", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) == DialogResult.OK))!;

    public void Notify(string message) => Invoke(new Action(() =>
        MessageBox.Show(this, message, Text, MessageBoxButtons.OK, MessageBoxIcon.Information)));

    public bool AskRetry(string message) => (bool)Invoke(new Func<bool>(() =>
        MessageBox.Show(this, message, Text, MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning) == DialogResult.Retry))!;

    public void RequestStopAfterCurrentRow()
    {
        _stopAfterRow = true;
        OnUi(() =>
        {
            if (_batchRunning) _stop.Text = "Abort now";
            Status("Will stop after the current row.");
        });
    }

    public void Log(string message)
    {
        _runLog.Write(message);
        OnUi(() => _log.AppendText($"{DateTime.Now:HH:mm:ss}  {message}{Environment.NewLine}"));
    }

    public void Status(string message) => OnUi(() => _status.Text = message);

    // =====================================================================================  actions

    /// <summary>VB6 Log_Onto_HOD_cmd_Click / Web_Logon. Opens the HOD launch URL (at most once per 10 s).</summary>
    private void StartHod()
    {
        string url = _hodUrl.Text.Trim();
        if (url.Length == 0) return;
        if ((DateTime.Now - _lastHodLaunch).TotalSeconds < 10)
        {
            Status("HOD is already starting; give it a few seconds.");
            return;
        }
        _lastHodLaunch = DateTime.Now;

        try
        {
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            Log("Opening HOD: " + url);
            Status("HOD is starting. If Java asks, click Run. When the Tax System screen shows in your session, click Connect.");
        }
        catch (Exception ex)
        {
            ShowError("Couldn't open " + url + Environment.NewLine + Environment.NewLine + ex.Message);
        }
    }

    /// <summary>VB6 Logon_Click.</summary>
    private async Task ConnectAsync()
    {
        if (_busy) return;
        string session = _session.Text.Trim().ToUpperInvariant();
        if (session.Length != 1)
        {
            ShowError("Enter the HOD session letter (normally A).");
            return;
        }
        string userId = _userId.Text.Trim();
        string password = _password.Text.Trim();
        SaveSettings();

        Status("Connecting to HOD session " + session + "…");
        if (await RunOnWorkerAsync("Connect", batch: false, () => _tops.SignOn(session, userId, password)))
            Status("Signed on. Pick the spreadsheet and click Update per file.");
    }

    /// <summary>VB6 Process_Sheet_Click.</summary>
    private async Task RunBatchAsync()
    {
        if (_busy) return;
        if (!_host.LoggedOn)
        {
            ShowError("Not attached to HOD yet. Click Connect first.");
            return;
        }

        string file = _sourceFile.Text.Trim();
        int saveEvery = (int)_saveEvery.Value;
        SaveSettings();

        BatchSummary? summary = null;
        bool ok = await RunOnWorkerAsync("Update", batch: true,
            () => summary = _batch.Run(file, saveEvery, () => _stopAfterRow, TakeSaveRequest));

        if (ok && summary is not null)
        {
            string counts = $"posted {summary.Posted}, already done {summary.AlreadyDone}, skipped {summary.Skipped}";
            string text = summary.StoppedEarly
                ? $"Stopped on request ({counts}). Run it again to continue. File: {summary.FilePath}"
                : $"ALL DONE-- SEE THE UPDATE FILE-- {summary.FilePath}  ({counts})";
            Log(text);
            Status(text);
            OpenFile(summary.FilePath);
        }
    }

    private bool TakeSaveRequest()
    {
        if (!_saveRequested) return false;
        _saveRequested = false;
        return true;
    }

    /// <summary>First click: finish the current row, then stop. Second click (or any click while connecting): abort now.</summary>
    private void StopClicked()
    {
        if (_batchRunning && !_stopAfterRow)
        {
            _stopAfterRow = true;
            _stop.Text = "Abort now";
            Log("Stopping after the current row. Click Abort now to stop immediately.");
            Status("Stopping after the current row…");
        }
        else
        {
            _cts.Cancel();
            Log("Abort requested.");
        }
    }

    private async Task<bool> RunOnWorkerAsync(string what, bool batch, Action work)
    {
        _cts.Dispose();
        _cts = new CancellationTokenSource();
        _stopAfterRow = false;
        _saveRequested = false;
        SetBusy(true, batch);
        try
        {
            await _worker.RunAsync(work);
            return true;
        }
        catch (BatchInterruptedException ex)
        {
            Log(ex.Message.Replace(Environment.NewLine, " "));
            Status(what + " stopped. See the message and the log.");
            if (!_closing) ShowWarning(ex.Message);
        }
        catch (OperationCanceledException)
        {
            Log(what + " stopped by the operator.");
            Status(what + " stopped.");
        }
        catch (Exception ex)
        {
            Log($"{what} failed: {ex.Message.Replace(Environment.NewLine, " ")}");
            Status(what + " failed. See the message and the log.");
            if (!_closing) ShowError(ex.Message);
        }
        finally
        {
            SetBusy(false, false);
        }
        return false;
    }

    private void SetBusy(bool busy, bool batch)
    {
        _busy = busy;
        _batchRunning = batch;
        foreach (Control c in new Control[] { _connect, _run, _browse, _zHod, _newHod, _oldHod, _hodUrl, _session, _userId, _password })
            c.Enabled = !busy;
        _sourceFile.ReadOnly = busy;
        _stop.Enabled = busy;
        _stop.Text = "Stop";
        _saveNow.Enabled = batch;
    }

    private void BrowseForFile()
    {
        using var dialog = new OpenFileDialog
        {
            Title = "Void / stop check list",
            Filter = "Excel workbooks (*.xlsx;*.xlsm;*.xls)|*.xlsx;*.xlsm;*.xls|All files (*.*)|*.*",
        };
        try
        {
            string current = _sourceFile.Text.Trim();
            string? folder = Path.GetDirectoryName(current);
            if (!string.IsNullOrEmpty(folder) && Directory.Exists(folder))
            {
                dialog.InitialDirectory = folder;
                dialog.FileName = Path.GetFileName(current);
            }
        }
        catch (ArgumentException)
        {
            // bad path in the box; just open the dialog with defaults
        }

        if (dialog.ShowDialog(this) == DialogResult.OK)
            _sourceFile.Text = dialog.FileName;
    }

    private void OpenFile(string path)
    {
        try
        {
            Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            Log("Couldn't open the spreadsheet: " + ex.Message);
        }
    }

    // =====================================================================================  closing

    protected override async void OnFormClosing(FormClosingEventArgs e)
    {
        if (_readyToClose)
        {
            base.OnFormClosing(e);
            return;
        }

        e.Cancel = true;
        if (_closing) return;

        if (_busy &&
            MessageBox.Show(this,
                "A run is in progress. Stop it and exit?" + Environment.NewLine + Environment.NewLine +
                "The spreadsheet is saved before the program closes.",
                Text, MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
        {
            return;
        }

        _closing = true;
        SaveSettings();
        _cts.Cancel();

        // Let the worker unwind (it saves the spreadsheet and quits Excel), then detach from HOD (VB6 HOD_LogOff).
        var clock = Stopwatch.StartNew();
        while (_busy && clock.Elapsed < TimeSpan.FromSeconds(30))
            await Task.Delay(100);

        if (!_busy)
        {
            try { await _worker.RunAsync(_host.Disconnect).WaitAsync(TimeSpan.FromSeconds(10)); }
            catch { /* best effort */ }
        }

        _readyToClose = true;
        await Task.Yield(); // make sure Close() isn't re-entered from inside this FormClosing call
        Close();
    }

    protected override void OnFormClosed(FormClosedEventArgs e)
    {
        _worker.Dispose();
        _cts.Dispose();
        base.OnFormClosed(e);
    }

    // =====================================================================================  settings

    private HodVersion SelectedHodVersion =>
        _oldHod.Checked ? HodVersion.OldHod : _newHod.Checked ? HodVersion.NewHod : HodVersion.ZHod;

    private void ApplySettings()
    {
        _hodUrl.Text = _settings.HodUrl;
        _session.Text = string.IsNullOrWhiteSpace(_settings.Session) ? "A" : _settings.Session;
        _sourceFile.Text = _settings.SourceFile;
        _saveEvery.Value = Math.Clamp(_settings.SaveEvery, 0, 100000);
        _timeout.Value = Math.Clamp(_settings.TimeoutSeconds, 0, 3600);
        _timeoutSeconds = (int)_timeout.Value;

        // Checking a radio button recomputes the URL, as VB6 Form_Load did with the zHOD box.
        RadioButton radio = _settings.HodVersion switch
        {
            "Old" => _oldHod,
            "New" => _newHod,
            _ => _zHod,
        };
        radio.Checked = true;
    }

    private void SaveSettings()
    {
        _settings.HodVersion = SelectedHodVersion switch
        {
            HodVersion.OldHod => "Old",
            HodVersion.NewHod => "New",
            _ => "zHOD",
        };
        _settings.HodUrl = _hodUrl.Text.Trim();
        _settings.Session = _session.Text.Trim();
        _settings.SourceFile = _sourceFile.Text.Trim();
        _settings.SaveEvery = (int)_saveEvery.Value;
        _settings.TimeoutSeconds = (int)_timeout.Value;
        _settings.Save(AppPaths.SettingsFile);
    }

    // =====================================================================================  layout

    private void WireEvents()
    {
        foreach (RadioButton radio in new[] { _zHod, _newHod, _oldHod })
        {
            radio.CheckedChanged += (_, _) =>
            {
                if (radio.Checked) _hodUrl.Text = HodUrls.For(SelectedHodVersion, _hodUrl.Text);
            };
        }

        _startHod.Click += (_, _) => StartHod();
        _connect.Click += async (_, _) => await ConnectAsync();
        _browse.Click += (_, _) => BrowseForFile();
        _run.Click += async (_, _) => await RunBatchAsync();
        _stop.Click += (_, _) => StopClicked();
        _saveNow.Click += (_, _) =>
        {
            _saveRequested = true;
            Log("Save requested: the spreadsheet will be saved before the next row.");
        };
        _exit.Click += (_, _) => Close();
        _checkpoints.CheckedChanged += (_, _) => _checkpointsOn = _checkpoints.Checked;
        _timeout.ValueChanged += (_, _) => _timeoutSeconds = (int)_timeout.Value;
    }

    private void BuildLayout()
    {
        SuspendLayout();

        Text = "Post DP40 Void Checks - TOPS Data Access";
        Font = new Font("Segoe UI", 9F);
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(Dpi(860), Dpi(800));
        MinimumSize = new Size(Dpi(720), Dpi(640));

        _session.Width = Dpi(32);
        _userId.Width = Dpi(140);
        _password.Width = Dpi(140);
        _saveEvery.Width = Dpi(70);
        _timeout.Width = Dpi(70);
        _log.Font = new Font("Consolas", 9F);
        _status.Font = new Font(Font, FontStyle.Bold);
        _status.Margin = new Padding(0, Dpi(8), 0, Dpi(4));
        _wrappingLabels.Add(_status);

        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, Padding = new Padding(Dpi(12)) };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));

        AddRow(root, new Label
        {
            Text = "Post DP40 Void Checks",
            AutoSize = true,
            Font = new Font("Segoe UI Semibold", 16F),
            Margin = new Padding(0, 0, 0, Dpi(2)),
        });
        AddRow(root, WrappingLabel(
            "1. Click Start HOD and make sure your Tax session (normally A) shows the Tax System screen; close any HOD sessions you don't need.   " +
            "2. Enter your TOPS user ID and password, click Connect, and wait for the TOPS main menu.   " +
            "3. Pick the spreadsheet and click Update per file."));

        // 1. Host On-Demand
        AddRow(root, Section("Host On-Demand"));
        var versions = new FlowLayoutPanel { AutoSize = true, WrapContents = false, Margin = Padding.Empty, Anchor = AnchorStyles.Left };
        versions.Controls.AddRange(new Control[] { _zHod, _newHod, _oldHod });
        var hod = Grid(columns: 3, rows: 3);
        hod.Controls.Add(FieldLabel("Version"), 0, 0);
        hod.Controls.Add(versions, 1, 0);
        hod.Controls.Add(FieldLabel("HOD address"), 0, 1);
        hod.Controls.Add(_hodUrl, 1, 1);
        hod.Controls.Add(_startHod, 2, 1);
        hod.Controls.Add(FieldLabel("Session"), 0, 2);
        _session.Anchor = AnchorStyles.Left;
        hod.Controls.Add(_session, 1, 2);
        AddRow(root, hod);

        // 2. Sign on
        AddRow(root, Section("Sign on to TOPS"));
        AddRow(root, Row(FieldLabel("User ID"), _userId, FieldLabel("   Password"), _password, Spacer(), _connect));

        // 3. Spreadsheet
        AddRow(root, Section("Void / stop check list"));
        var file = Grid(columns: 3, rows: 1);
        file.Controls.Add(FieldLabel("Source file"), 0, 0);
        file.Controls.Add(_sourceFile, 1, 0);
        file.Controls.Add(_browse, 2, 0);
        AddRow(root, file);
        AddRow(root, WrappingLabel(
            "Sheet 1, one check per row:  A = Disb Acct   B = Check Number   C = Check Amount   D = Void (1) or Stop (2)   E = Federal (1) or State (2).   " +
            "The TOPS result is written to column T. Rows that already have something in column T are skipped, so running again picks up where it left off."));
        AddRow(root, Row(_checkpoints, FieldLabel("     Save every"), _saveEvery, FieldLabel("rows"),
            FieldLabel("     Screen timeout"), _timeout, FieldLabel("seconds (0 = wait forever)")));

        // Actions
        var buttons = Row(_run, _stop, _saveNow, Spacer(), _exit);
        buttons.Margin = new Padding(Dpi(8), Dpi(10), 0, 0);
        AddRow(root, buttons);
        AddRow(root, _status);
        AddRow(root, _log, fill: true);

        root.Resize += (_, _) =>
        {
            int width = Math.Max(Dpi(200), root.ClientSize.Width - root.Padding.Horizontal - Dpi(16));
            foreach (Label label in _wrappingLabels)
                label.MaximumSize = new Size(width, 0);
        };

        Controls.Add(root);
        ResumeLayout(performLayout: true);
    }

    private int Dpi(int value) => LogicalToDeviceUnits(value);

    private static void AddRow(TableLayoutPanel root, Control control, bool fill = false)
    {
        int row = root.RowStyles.Count;
        root.RowStyles.Add(fill ? new RowStyle(SizeType.Percent, 100F) : new RowStyle(SizeType.AutoSize));
        root.RowCount = row + 1;
        root.Controls.Add(control, 0, row);
    }

    private Label Section(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Font = new Font(Font.FontFamily, 10.5F, FontStyle.Bold),
        Margin = new Padding(0, Dpi(12), 0, Dpi(4)),
    };

    private Label WrappingLabel(string text)
    {
        var label = new Label { Text = text, AutoSize = true, Margin = new Padding(Dpi(8), Dpi(2), 0, Dpi(4)) };
        _wrappingLabels.Add(label);
        return label;
    }

    private static Label FieldLabel(string text) => new() { Text = text, AutoSize = true, Anchor = AnchorStyles.Left };

    private Control Spacer() => new Panel { Width = Dpi(24), Height = 1, Margin = Padding.Empty };

    /// <summary>Label column (auto), stretch column (fills), then auto columns.</summary>
    private TableLayoutPanel Grid(int columns, int rows)
    {
        var grid = new TableLayoutPanel
        {
            ColumnCount = columns,
            RowCount = rows,
            AutoSize = true,
            Dock = DockStyle.Fill,
            Margin = new Padding(Dpi(8), 0, 0, 0),
        };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
        for (int i = 2; i < columns; i++) grid.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        for (int i = 0; i < rows; i++) grid.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        return grid;
    }

    /// <summary>A single row of controls, each vertically centred.</summary>
    private TableLayoutPanel Row(params Control[] controls)
    {
        var row = new TableLayoutPanel
        {
            ColumnCount = controls.Length,
            RowCount = 1,
            AutoSize = true,
            Anchor = AnchorStyles.Left | AnchorStyles.Top,
            Margin = new Padding(Dpi(8), 0, 0, 0),
        };
        row.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        for (int i = 0; i < controls.Length; i++)
        {
            row.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            controls[i].Anchor = AnchorStyles.Left;
            row.Controls.Add(controls[i], i, 0);
        }
        return row;
    }

    // =====================================================================================  helpers

    private void OnUi(Action action)
    {
        if (IsDisposed || Disposing) return;
        if (InvokeRequired) BeginInvoke(action);
        else action();
    }

    private void ShowError(string message) =>
        MessageBox.Show(this, message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);

    private void ShowWarning(string message) =>
        MessageBox.Show(this, message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
}
