using System;
using System.Windows.Forms;

namespace PostDP40VoidChecks;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.SetHighDpiMode(HighDpiMode.SystemAware);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);

        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, e) => ShowCrash(e.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, e) => ShowCrash(e.ExceptionObject as Exception);

        if (Environment.Is64BitProcess)
        {
            MessageBox.Show(
                "This build is running as a 64-bit process, so it can't load the 32-bit ATMAPI32.DLL." +
                Environment.NewLine + "Rebuild it with -r win-x86 (see README.md).",
                "Post DP40 Void Checks", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        Application.Run(new MainForm());
    }

    private static void ShowCrash(Exception? ex)
    {
        try
        {
            new RunLog(AppPaths.LogFolder).Write("UNEXPECTED ERROR: " + ex);
            MessageBox.Show("Unexpected error:" + Environment.NewLine + Environment.NewLine + ex?.Message,
                "Post DP40 Void Checks", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        catch
        {
            // nothing more we can do
        }
    }
}
