# Post DP40 Void Checks (.NET 10)

A C#/.NET 10 rewrite of the VB6 program `FutaFix.vbp` / `FutaFix.frm`
("HOD_Version-- Post_DP40_Void_Checks"). It does the same job: it reads a list of checks from Excel
and posts each void or stop request to TOPS transaction **DP40** through Host On-Demand session A.
It uses the same `ATMAPI32.DLL` calls, screens, field positions, keys, waits and delays as the original.

## Build

You need a Windows PC with the [.NET 10 SDK](https://dotnet.microsoft.com/download/dotnet/10.0).

```
build.cmd
```

or

```
dotnet publish -c Release -r win-x86 --self-contained true -p:PublishSingleFile=true -o publish
```

The output is `publish\PostDP40VoidChecks.exe`, a single exe that doesn't need .NET installed on the PCs that run it.

**It must be built x86 (32-bit).** `ATMAPI32.DLL` is a 32-bit DLL, and a 64-bit process can't load it.
The project file already forces x86. If someone builds it 64-bit anyway, the exe shows an error at startup and exits.

## Requirements on the PC that runs it

Most PCs that ran the VB6 version already have all of these:

- Windows 10/11
- `ATMAPI32.DLL`, found on the PATH, in `C:\Windows\SysWOW64`, or next to the exe. The VB6 version needed it too
  (see the old comment about running `ehllapi.exe`).
- Host On-Demand with the Tax session (normally A)
- Microsoft Excel. It's used through COM, the same as the original, with any version.

## Using it

1. **Start HOD**: opens the HOD launch URL for the version you pick (zHOD by default, or New/Old HOD).
   Click Run if Java asks. Make sure your Tax session shows the Tax System screen.
2. **Connect**: attaches to the session and signs on: CICSA → clear → TAX3 → user ID/password →
   department/group menu. If the session is already at the TOPS main menu, it stops there.
3. **Update per file**: for every row on sheet 1 where column T is empty and the data is valid, it posts DP40
   and writes the TOPS message to column T as `MESSAGE-- mm-dd-yyyy  hh:mm:ss`, the same format as before.

| Column | Contents |
|---|---|
| A | Disb Acct (1-2 chars) |
| B | Check Number (1-8 chars) |
| C | Check Amount (not zero; `125.00-` with a trailing minus is negative) |
| D | 1 = Void, 2 = Stop |
| E | 1 = Federal, 2 = State |
| T | Result (filled in by the program) |

**Checkpoints** is on by default, as in the original. Before every key press it asks *OK to press Enter (@E)?*
In this version, **Cancel** stops the run safely. After each post it shows the result.
Turn Checkpoints off for an unattended run. You can turn it back on mid-run.

**Stop** finishes the current row and then stops. Click it again (**Abort now**) to stop immediately.
**Save now** saves the spreadsheet before the next row.

## Where things go

`%LOCALAPPDATA%\PostDP40VoidChecks\` contains:

- `logs\PostDP40-yyyy-mm-dd.log`: every row posted, every TOPS result, every skip and error. Passwords are never logged.
- `backups\`: a copy of the spreadsheet taken before each run.
- `settings.json`: the last HOD version/URL, session, file, Save every and timeout. Credentials aren't saved, and
  Checkpoints always starts on.

## What changed from the VB6 version

The host flow is a straight port. These are the only behaviour changes:

| VB6 | Now |
|---|---|
| Every screen wait looped forever (bad password, unexpected screen or protected field = hung program). | Each wait gives up after the **Screen timeout** (default 120 s; 0 = wait forever, like before). The run stops, the sheet is saved and the message says which row was in progress. Time spent answering checkpoint dialogs doesn't count against the timeout. |
| Checkpoint boxes were OK-only, and some keys got two boxes in a row ("Press 'Enter' here?" then "OK to press @E?"). | One OK/Cancel box per key. Cancel stops the run before the key is sent. |
| "Save every N" never saved (its counter was never incremented). | Saves every N posted rows. |
| The **S** button closed the workbook mid-run, and the next row crashed. | **Save now** saves at the next safe point. |
| `CheckExcel` offered to close whatever Excel workbook you had open; Cancel ended the program. | Only checks whether *this* file is open somewhere, and asks you to close it (Retry/Cancel). |
| The whole run was in one thread with `DoEvents`; Exit was the only way out. | Automation runs on a background thread. The window stays responsive, with Stop / Abort. |
| Blank Disb Acct or Check Number passed validation. | Rows with blank A or B, or with Excel error values in A-E, are skipped and logged. |
| Clicking Update when not connected looped forever pressing PF15. | Asks you to click Connect first. |
| A failed Connect left it "logged on" so it never re-attached. | A failed Connect detaches, so the next Connect starts clean. |
| HOD started in an embedded Internet Explorer control. | Opens the URL with the default browser / Java Web Start handler. |
| At the end, Excel was shown and closed when you clicked OK. | The saved file opens in Excel normally. |
| Start-up instructions pop-up and the "Logging on to HOD" pop-up. | The steps are shown on the window; progress goes to the status line and log. |
| Expiry check (01/01/2099), Paul F.'s contact text, the masked User ID box. | Removed. The User ID shows normally. |

**Kept on purpose:** the DPI1100(DPI1101) branch. It came from an older "SIT deposit frequency" program, and
it treats column B as a frequency (MN/QT). If TOPS ever lands on DPI1100(DPI1101) after a post, the program shows
"INVALID FREQUENCY--" and records it, exactly as before. It's isolated in `TopsAutomation.LegacyFrequencyBranch`
if you want to delete it.

**Also kept:**

- A leading minus on an amount is ignored; only a trailing minus counts.
- D and E aren't checked for 1/2; TOPS validates them.

## Testing before real use

1. Build, copy the exe to a PC that ran the VB6 version, and start it.
2. Make a test sheet with one or two rows you're allowed to post. Run with **Checkpoints on** and compare each
   prompt with what the VB6 version did.
3. Check column T and the log file.

## Source layout

| File | Contents |
|---|---|
| `Host/AtmApi.cs` | `ATMAPI32.DLL` declarations (VB6 `Declare` lines) |
| `Host/HostSession.cs` | Screen read/write, keys, `Delays`, `Timerx`, waits with timeout |
| `Automation/TopsAutomation.cs` | Sign-on and the DP40 post flow |
| `Automation/BatchRunner.cs` | The spreadsheet loop (`Process_Sheet_Click`) |
| `Automation/VoidCheckRow.cs` | Reading/validating one row |
| `Automation/VbCompat.cs` | VB string/number behaviour (`TU$`, `NumVal`, `Val`, `Date$`/`Time$` stamp) |
| `Excel/ExcelWorkbook.cs` | Late-bound Excel COM |
| `MainForm.cs` | The window |
