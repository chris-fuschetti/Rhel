@echo off
rem Builds a single, self-contained 32-bit PostDP40VoidChecks.exe into .\publish
rem Needs the .NET 10 SDK: https://dotnet.microsoft.com/download/dotnet/10.0
setlocal
cd /d "%~dp0"
dotnet publish PostDP40VoidChecks.csproj -c Release -r win-x86 --self-contained true -p:PublishSingleFile=true -o publish
if errorlevel 1 (
  echo.
  echo BUILD FAILED
  exit /b 1
)
echo.
echo Done: %~dp0publish\PostDP40VoidChecks.exe
